#include<iostream>
#include<fstream>
#include<ctime>
#include<bits/stdc++.h>
using namespace std;

// #define tot_levels 4
// #define n_ary 3
// #define no_req 1000

//based on levels and k_ary we need to find start of leaf and end of leaf.
//As per our structure 0 is the cloud node and cloud is level 1 .
int main()
{
	srand(time(0));
	int tot_levels=4;
	int n_ary=4;
	int no_req=10000;
	ofstream data_file;
	data_file.open("data_file_4_4_10000.txt");
	fstream loc_file;
	loc_file.open("locations_3_3_100.txt");
	fstream ded_file;
	ded_file.open("dead_100.txt");
	int tot_nodes=(pow(n_ary,tot_levels)-1)/(n_ary-1);
	int leafs=pow(n_ary,tot_levels-1);
	int s_leaf=tot_nodes-leafs;
	int e_leaf=tot_nodes;
	cout<<s_leaf<<" "<<e_leaf<<"\n";
	//generate random data_id[1-50],l_id[s_leaf,e_leaf),dead_id[1-12],prf_id[1,20].
	if(data_file.is_open() && loc_file.is_open() && ded_file.is_open())
	{
		data_file<<no_req<<"\n";
		for(int i=0;i<no_req;i++)
		{
		int data_id=rand()%50+1;
		// int l_id;
		// loc_file>>l_id;
		int l_id=s_leaf+(rand()%(e_leaf-s_leaf));
		int dead=rand()%15+1;
		// int dead;
		// ded_file>>dead;
		int prf=50/dead;
		data_file<<data_id<<" "<<l_id<<" "<<dead<<" "<<prf<<"\n";	
		}
		data_file.close();
		loc_file.close();
		ded_file.close();
	}
	else cout<<"File can't be opened!";
	
	return 1;	
}