#include<iostream>
#include<bits/stdc++.h>
using namespace std;

/*
	This is a random Placement strategy were we will traverse each request,
	randomly select the level and put the request over there if it satisfies the
	deadline else request is disgarded.
*/

int tot_levels;
int tot_requests;
int n_ary;
int tot_nodes;
vector<vector<int>> req;
vector<int> space;				//space for each nodes
vector<int> delay;				//delay for each node from leaf.
vector<int> nodes_space;		//To know space left at each node.
vector<multimap<int,int>> nodes_profit_content; 	//To know profit,content present at each node
vector<unordered_map<int,vector<int>>> nodes_content_req;	//Gives content stored and its reauests at each node.
vector<int> parent;	//Cloud is 0th node
vector<bool> req_satisfied;
int net_profit=0;
ofstream results_file;
void intialize_architecture()
{
	// total_no of levels
	// Each level space and delay
	// no of nodes connected to each node (n-ary tree).
	cin>>tot_levels;
	cin>>n_ary;
	space.resize(tot_levels,INT_MAX);		//Each node in a level has same space.
	delay.resize(tot_levels,0);				//Each node in a level has same delay.
	int space_decr_perc,delay_decr_perc;
	int init_space;
	int init_delay;
	
	

	cin>>init_space>>init_delay;			//Takes inital space of level 1 and delay till cloud. 
	cin>>space_decr_perc>>delay_decr_perc;	//Percentage decrement from previous level.
	
	results_file.open("RDresults_file_4_4_10000_4_10_rd.txt");
	if(!results_file.is_open())
	{
		cout<<"File not Openend!";
	}

	results_file<<"Init Space: "<<init_space<<" Init delay "<<init_delay<<" decr Percentage"<<space_decr_perc<<" "<<delay_decr_perc<<"\n";

	//For space node 0 has MAX space.
	for(int i=1;i<tot_levels;i++)
	{
		space[i]=init_space;
		init_space=init_space-ceil(init_space*space_decr_perc)/100;		
	}

	//For delay node 0 is cloud and from it all will decrease in delay.
	for(int i=0;i<tot_levels;i++)
	{
		delay[i]=init_delay;
		init_delay=init_delay-ceil(init_delay*delay_decr_perc)/100;
	}

	//Total no of nodes in architecture would be N_ary^level.
	tot_nodes=(pow(n_ary,tot_levels)-1)/(n_ary-1);
	nodes_space.resize(tot_nodes+1,INT_MAX);				
	parent.resize(tot_nodes+1,0);
	nodes_content_req.resize(tot_nodes+1);
	nodes_profit_content.resize(tot_nodes+1);
	//	nodes_profit.resize(total_nodes+1,0);		
	

	results_file<<"Total Nodes are: "<<tot_nodes<<endl;
	//intializing space for all nodes.
	//And initializing parents.
	int counter=1;
	for(int i=1;i<tot_levels;i++)
	{
		int nodes=pow(n_ary,i);
		for(int j=0;j<nodes;j++)
		{
			nodes_space[counter]=space[i];
			int temp=counter%n_ary;
			int x= counter/n_ary;
			if(temp==0)	x--;
			cout<<"Counter: "<<counter<<" parent: "<<x<<"\n";
			parent[counter]=x;
			counter++;
		}
	}

	//Printing nodes space for all nodes;
	for(int i=0;i<nodes_space.size();i++)
	{
		cout<<"Node: "<<i<<" space: "<<nodes_space[i]<<" parent: "<<parent[i]<<"\n";
	}
	//Now initializing requests.
	//Location should be from leaf nodes only.
	//Need to take this from file.
	fstream data_file;
	data_file.open("Data/data_file_4_4_10000_rd.txt");
	if(!data_file.is_open())
	{
		cout<<"File Can't be opened\n";
		exit(0);
	}
	data_file>>tot_requests;
	int tot_prf=0;
	for(int i=0;i<tot_requests;i++)
	{
		int ci,li,di,pi;
		data_file>>ci>>li>>di>>pi;
		vector<int> r;
		r.push_back(ci),r.push_back(li),r.push_back(di),r.push_back(pi);
		req.push_back(r);
		req_satisfied.push_back(false);
		tot_prf+=pi;
	}
	// for(int i=0;i<tot_requests;i++)
	// {
	// 	cout<<req[i][0]<<req[i][1]<<req[i][2]<<req[i][3]<<"\n";
	// }
	results_file<<"Total possible profit: "<<tot_prf<<"\n";
	data_file.close();
}

int main()
{
	intialize_architecture();
	// Traverse each request and place it randomly based on levels.
	int earned_profit=0;
	//This tells me which contents are present at every node.
	unordered_map<int,unordered_set<int>> node_cont;
	for(int i=0;i<tot_requests;i++)
	{
		int del=req[i][2];
		int cont=req[i][0];
		int rand_lev= rand()%tot_levels;
		//if generated random level is inside delay then only place it.
		if(delay[rand_lev]>del)	continue;
		//Based on parent property find the node at that level in path.
		int curr_node=req[i][1];
		int curr_lev=tot_levels-1;
		while(curr_lev!=rand_lev)	curr_node=parent[curr_node],curr_lev--;
		if(nodes_space[curr_node]>0)	nodes_space[curr_node]--,earned_profit+=req[i][3];
	}
	cout<<"Total Profit earned: "<<earned_profit;
	results_file<<"Total Profit earned: "<<earned_profit;
}