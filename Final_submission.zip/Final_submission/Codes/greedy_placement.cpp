#include<iostream>
#include<bits/stdc++.h>
using namespace std;

/*
	In Greedy we will sort based on contents profit and than place each request.
	Placement will start from leaf, if not satisfied with space go one step up untill deadline.
*/

int tot_levels;
int tot_requests;
int n_ary;
int tot_nodes;
vector<vector<int>> req;
vector<int> space;				//space for each nodes
vector<int> delay;				//delay for each node from leaf.
vector<int> nodes_space;		//To know space left at each node.
vector<map<int,int>> nodes_profit_content; 	//To know profit,content present at each node
vector<unordered_map<int,int>> nodes_content;	//Gives content stored and its requests at each node.
vector<int> parent;	//Cloud is 0th node
vector<bool> req_satisfied;
int net_profit=0;
ofstream results_file;
void intialize_architecture()
{
	// total_no of levels
	// Each level space and delay
	// no of nodes connected to each node (n-ary tree).
	cin>>tot_levels;
	cin>>n_ary;
	space.resize(tot_levels,INT_MAX);		//Each node in a level has same space.
	delay.resize(tot_levels,0);				//Each node in a level has same delay.
	int space_decr_perc,delay_decr_perc;
	int init_space;
	int init_delay;
	
	

	cin>>init_space>>init_delay;			//Takes inital space of level 1 and delay till cloud. 
	cin>>space_decr_perc>>delay_decr_perc;	//Percentage decrement from previous level.
	
	results_file.open("GDresults_file_4_4_10000_4_10.txt");
	if(!results_file.is_open())
	{
		cout<<"File not Openend!";
	}

	results_file<<"Init Space: "<<init_space<<" Init delay "<<init_delay<<" decr Percentage"<<space_decr_perc<<" "<<delay_decr_perc<<"\n";

	//For space node 0 has MAX space.
	for(int i=1;i<tot_levels;i++)
	{
		space[i]=init_space;
		init_space=init_space-ceil(init_space*space_decr_perc)/100;		
	}

	//For delay node 0 is cloud and from it all will decrease in delay.
	for(int i=0;i<tot_levels;i++)
	{
		delay[i]=init_delay;
		init_delay=init_delay-ceil(init_delay*delay_decr_perc)/100;
	}

	//Total no of nodes in architecture would be N_ary^level.
	tot_nodes=(pow(n_ary,tot_levels)-1)/(n_ary-1);
	nodes_space.resize(tot_nodes+1,INT_MAX);				
	parent.resize(tot_nodes+1,0);
	nodes_content.resize(tot_nodes+1);
	nodes_profit_content.resize(tot_nodes+1);
	//	nodes_profit.resize(total_nodes+1,0);		
	

	results_file<<"Total Nodes are: "<<tot_nodes<<endl;
	//intializing space for all nodes.
	//And initializing parents.
	int counter=1;
	for(int i=1;i<tot_levels;i++)
	{
		int nodes=pow(n_ary,i);
		for(int j=0;j<nodes;j++)
		{
			nodes_space[counter]=space[i];
			int temp=counter%n_ary;
			int x= counter/n_ary;
			if(temp==0)	x--;
			cout<<"Counter: "<<counter<<" parent: "<<x<<"\n";
			parent[counter]=x;
			counter++;
		}
	}

	//Printing nodes space for all nodes;
	for(int i=0;i<nodes_space.size();i++)
	{
		cout<<"Node: "<<i<<" space: "<<nodes_space[i]<<" parent: "<<parent[i]<<"\n";
	}
	//Now initializing requests.
	//Location should be from leaf nodes only.
	//Need to take this from file.
	fstream data_file;
	data_file.open("Data/data_file_4_4_10000.txt");
	if(!data_file.is_open())
	{
		cout<<"File Can't be opened\n";
		exit(0);
	}
	data_file>>tot_requests;
	int tot_prf=0;
	for(int i=0;i<tot_requests;i++)
	{
		int ci,li,di,pi;
		data_file>>ci>>li>>di>>pi;
		vector<int> r;
		r.push_back(ci),r.push_back(li),r.push_back(di),r.push_back(pi);
		req.push_back(r);
		req_satisfied.push_back(false);
		tot_prf+=pi;
	}
	// for(int i=0;i<tot_requests;i++)
	// {
	// 	cout<<req[i][0]<<req[i][1]<<req[i][2]<<req[i][3]<<"\n";
	// }
	results_file<<"Total possible profit: "<<tot_prf<<"\n";
	data_file.close();
}

/*
	We will first find maximum profit from each content. Using map we can achieve it.
	We also need to store the requests for each content.
	For placement we will start leaf node.
	we won't make path array using parent array we will on the go find the parent.
*/

int placement_algo(int r_no)
{
	vector<int> request=req[r_no];
	int node=request[1];
	int deadline=request[2];
	//Finding node with free space or content already present or deadline achieved
	int level=tot_levels-1;
	while(nodes_space[node]<=0 && level!=0){
		if(deadline<delay[level])	return 0;
		if(nodes_content[node].count(request[0])!=0)	return request[3];
		node=parent[node];
		level--;
	}
	if(deadline<delay[level])	return 0;
	if(nodes_content[node].count(request[0])!=0)	return request[3];
	nodes_space[node]--;
	nodes_content[node][request[0]]++;
	return request[3];
}
	
int main()
{
	intialize_architecture();
 //Traverse all requests and as per content map all requests and profit achieved by them.
	unordered_map<int,vector<int>> cont_req;	//info about cont- req and cont-prf
	unordered_map<int,int> cont_prf;
	for(int i=0;i<tot_requests;i++)
	{
		cont_req[req[i][0]].push_back(i);
		cont_prf[req[i][0]]+=req[i][3];
	}
	vector<pair<int,int>> profit_content;
	for(auto m:cont_prf)
	{
		profit_content.push_back({m.second,m.first});
	}
	sort(profit_content.rbegin(),profit_content.rend());
	//Now contents are sorted based on profit.
	//Traverse for each content and for all request in it store them,
	int earned_prf=0;
	for(int i=0;i<profit_content.size();i++)
	{
		int cont=profit_content[i].second;
		vector<int> requests=cont_req[cont];
		for(auto r:requests)
		{
			earned_prf+=placement_algo(r);
		}
	}
	cout<<"Total earned profit: "<<earned_prf;
	results_file<<"Total earned profit: "<<earned_prf;

}