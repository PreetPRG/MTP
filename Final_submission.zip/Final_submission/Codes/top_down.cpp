#include<iostream>
#include<bits/stdc++.h>
using namespace std;

/*

			c
		/	|	\
		l1	l2	l3		
	At top cloud all request will be present.
	Now based on the location, request will be distributed in next level.
	At each location we need to make the call either to store over there or move it forward.
	Storing algo will be based on profit.
		Let all the contents request be present at particular location.
		Sort them based on profit each content can give.
		If for a certain content all requests deadline are satisfied than store it over there
		else move it to next levels.
	Cases that might occur:
		-If i am storing certain content having higher profit although it has more deadline as compared to next
		profitable, No issues as we can definitely store the next on next lvel as size of each content is same.
		We are considering profit.
		-No need to re settle any content.
		-Found a counter for this too
		10L,5,3
		My algo: 10, next level if 5 splits into 3L,2R and 3 on R, we will store 3L and 3R TP=16
		optimal: store 5 above, 10L and 3R:- TP=18.
*/

/*
		Traverse every requests but which to store?
		Sort requests based on profit than one request 3 profit will come first else of 5 requests of 1 profit.
		Calcullating of deadline won't be issue.
		Else Sort based on content profit.
		Filter out requests which can be satisfied at this deadline
		Now sum up all such requests for that content.
		And sort them based on profit.
		This looks good.
*/

int tot_levels;
int tot_requests;
int n_ary;
int tot_nodes;
vector<vector<int>> req;
vector<int> space;				//space for each nodes
vector<int> delay;				//delay for each node from leaf.
vector<int> nodes_space;		//To know space left at each node.
vector<multimap<int,int>> nodes_profit_content; 	//To know profit,content present at each node
vector<unordered_map<int,vector<int>>> nodes_content_req;	//Gives content stored and its reauests at each node.
vector<int> parent;	//Cloud is 0th node
vector<bool> req_satisfied;
int net_profit=0;
ofstream results_file;
void intialize_architecture()
{
	// total_no of levels
	// Each level space and delay
	// no of nodes connected to each node (n-ary tree).
	cin>>tot_levels;
	cin>>n_ary;
	space.resize(tot_levels,INT_MAX);		//Each node in a level has same space.
	delay.resize(tot_levels,0);				//Each node in a level has same delay.
	int space_decr_perc,delay_decr_perc;
	int init_space;
	int init_delay;
	
	

	cin>>init_space>>init_delay;			//Takes inital space of level 1 and delay till cloud. 
	cin>>space_decr_perc>>delay_decr_perc;	//Percentage decrement from previous level.
	
	results_file.open("TDresults_file_3_3_100_4_10_d.txt");
	if(!results_file.is_open())
	{
		cout<<"File not Openend!";
	}

	results_file<<"Init Space: "<<init_space<<" Init delay "<<init_delay<<" decr Percentage"<<space_decr_perc<<" "<<delay_decr_perc<<"\n";

	//For space node 0 has MAX space.
	for(int i=1;i<tot_levels;i++)
	{
		space[i]=init_space;
		init_space=init_space-ceil(init_space*space_decr_perc)/100;		
	}

	//For delay node 0 is cloud and from it all will decrease in delay.
	for(int i=0;i<tot_levels;i++)
	{
		delay[i]=init_delay;
		init_delay=init_delay-ceil(init_delay*delay_decr_perc)/100;
	}

	//Total no of nodes in architecture would be N_ary^level.
	tot_nodes=(pow(n_ary,tot_levels)-1)/(n_ary-1);
	nodes_space.resize(tot_nodes+1,INT_MAX);				
	parent.resize(tot_nodes+1,0);
	nodes_content_req.resize(tot_nodes+1);
	nodes_profit_content.resize(tot_nodes+1);
	//	nodes_profit.resize(total_nodes+1,0);		
	

	results_file<<"Total Nodes are: "<<tot_nodes<<endl;
	//intializing space for all nodes.
	//And initializing parents.
	int counter=1;
	for(int i=1;i<tot_levels;i++)
	{
		int nodes=pow(n_ary,i);
		for(int j=0;j<nodes;j++)
		{
			nodes_space[counter]=space[i];
			int temp=counter%n_ary;
			int x= counter/n_ary;
			if(temp==0)	x--;
			cout<<"Counter: "<<counter<<" parent: "<<x<<"\n";
			parent[counter]=x;
			counter++;
		}
	}

	//Printing nodes space for all nodes;
	for(int i=0;i<nodes_space.size();i++)
	{
		cout<<"Node: "<<i<<" space: "<<nodes_space[i]<<" parent: "<<parent[i]<<"\n";
	}
	//Now initializing requests.
	//Location should be from leaf nodes only.
	//Need to take this from file.
	fstream data_file;
	data_file.open("Data/data_file_3_3_100_d.txt");
	if(!data_file.is_open())
	{
		cout<<"File Can't be opened\n";
		exit(0);
	}
	data_file>>tot_requests;
	int tot_prf=0;
	for(int i=0;i<tot_requests;i++)
	{
		int ci,li,di,pi;
		data_file>>ci>>li>>di>>pi;
		vector<int> r;
		r.push_back(ci),r.push_back(li),r.push_back(di),r.push_back(pi);
		req.push_back(r);
		req_satisfied.push_back(false);
		tot_prf+=pi;
	}
	// for(int i=0;i<tot_requests;i++)
	// {
	// 	cout<<req[i][0]<<req[i][1]<<req[i][2]<<req[i][3]<<"\n";
	// }
	results_file<<"Total possible profit: "<<tot_prf<<"\n";
	data_file.close();
}

//We want to know each node has which requests
//To fill it we will traverse whole its path till cloud and populate it.
unordered_map<int,vector<int>> node_req;

//For each request this function makes its path to cloud and returns the path.
vector<int> make_path(vector<int> &single_req,int req_no)
{
	int curr_node=single_req[1];
	int dead_i=single_req[2];
	int curr_level=tot_levels-1;
	vector<int> path;
	//Untill we reach cloud or deadline has came.
	while(dead_i>=delay[curr_level] && curr_node!=0)
	{
		node_req[curr_node].push_back(req_no);
		path.push_back(curr_node);
		curr_node=parent[curr_node];
		curr_level--;
	}
	if(dead_i>=delay[0])
	{
		node_req[0].push_back(req_no);
	}
	return path;
}
int tot_earned_prf=0;
void placement_algo(int node)
{
	//collect all requests present at that node and which are not yet satisfied.
	//Now for each content collect the requests and sum up their profits.
	//As nodes will have deadline specific requests only so no issues of it.
	//Place and satisfy this requests.
	
	vector<int> requests;
	unordered_map<int,vector<int>> cont_req;
	unordered_map<int,int> cont_prf;
	for(auto r:node_req[node])
	{
		if(!req_satisfied[r])	cont_req[req[r][0]].push_back(r),cont_prf[req[r][0]]+=req[r][3];
	}
	
	vector<pair<int,int>> v;
	for(auto m:cont_prf)
	{
		v.push_back({m.second,m.first});
	}
	sort(v.rbegin(),v.rend());
	results_file<<"Node: "<<node<<" content present are: ";
	int node_prf=0;
	int sz=v.size();
	int counter=0;
	while(nodes_space[node]>0 && counter<sz)
	{
		node_prf+=v[counter].first;
		int c=v[counter].second;
		results_file<<c<<" ";
		for(auto r:cont_req[c])	req_satisfied[r]=true;
		nodes_space[node]--;
		counter++;
	}
	results_file<<" Profit earned: "<<node_prf<<"\n";
	tot_earned_prf+=node_prf;
	return;
}


int main()
{
	intialize_architecture();
	//We have all requests now for each node starting from top we need to do placement algo.
	//Traverse each level.
	//Need to start from top level and move to next level and for each level we need to
	//filter the requests which are not satisfied yet.
	// Suppose we have all the requests present at that node 
	// Than based on that filter and sum up based on content and place
	// Thus for each node instead of finding on runtime requests we can
	// Get it before also.
	for(int i=0;i<tot_requests;i++)
	{
		make_path(req[i],i);
	}
	//Now traverse each level and its node
	placement_algo(0);
	int counter=1;
	for(int i=1;i<tot_levels;i++)
	{
		int nodes=pow(n_ary,i);
		for(int j=0;j<nodes;j++)
		{
			placement_algo(counter);
			counter++;
		}
	}
	results_file<<"Total Earned profit is: "<<tot_earned_prf<<"\n";	
}