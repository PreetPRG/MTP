#include<iostream>
#include<bits/stdc++.h>
#include<fstream>
using namespace std;

/*
	We have all request in format of Ri(regi,Li,Di,Pi)
	Now, lets say profit and deadline is constant and deadline is such that all the request must be stored in intermidiate levels.
	Only thing here is if we store them in intermediate levels take LCA and store it over there.
	If any level is full store the data on next level or previous level of them.
	Here deadline needs to be taken care off. Here profit=1 so a new content request can only replace when its total profit is more than existing.

	With profit.
	Greedily sort the profit and than allocate accordingly.
	
	Deadline and profit comes with request and location.
*/

int tot_levels;
int tot_requests;
int n_ary;
int tot_nodes;
vector<vector<int>> req;
vector<int> space;				//space for each nodes
vector<int> delay;				//delay for each node from leaf.
vector<int> nodes_space;		//To know space left at each node.
vector<multimap<int,int>> nodes_profit_content; 	//To know profit,content present at each node
vector<unordered_map<int,vector<int>>> nodes_content_req;	//Gives content stored and its reauests at each node.
vector<int> parent;	//Cloud is 0th node
int net_profit=0;
ofstream results_file;
void intialize_architecture()
{
	// total_no of levels
	// Each level space and delay
	// no of nodes connected to each node (n-ary tree).
	cin>>tot_levels;
	cin>>n_ary;
	space.resize(tot_levels,INT_MAX);		//Each node in a level has same space.
	delay.resize(tot_levels,0);				//Each node in a level has same delay.
	int space_decr_perc,delay_decr_perc;
	int init_space;
	int init_delay;
	
	cin>>init_space>>init_delay;			//Takes inital space of level 1 and delay till cloud. 
	cin>>space_decr_perc>>delay_decr_perc;	//Percentage decrement from previous level.
	
	results_file.open("LCAresults_file_4_4_10000_4_10_rd.txt");
	if(!results_file.is_open())
	{
		cout<<"File not Openend!";
	}

	results_file<<"Init Space: "<<init_space<<" Init delay "<<init_delay<<" decr Percentage"<<space_decr_perc<<" "<<delay_decr_perc<<"\n";

	//For space node 0 has MAX space.
	for(int i=1;i<tot_levels;i++)
	{
		space[i]=init_space;
		init_space=init_space-ceil(init_space*space_decr_perc)/100;		
	}

	//For delay node 0 is cloud and from it all will decrease in delay.
	for(int i=0;i<tot_levels;i++)
	{
		delay[i]=init_delay;
		init_delay=init_delay-ceil(init_delay*delay_decr_perc)/100;
	}

	//Total no of nodes in architecture would be N_ary^level.
	tot_nodes=(pow(n_ary,tot_levels)-1)/(n_ary-1);
	nodes_space.resize(tot_nodes+1,INT_MAX);				
	parent.resize(tot_nodes+1,0);
	nodes_content_req.resize(tot_nodes+1);
	nodes_profit_content.resize(tot_nodes+1);
	//	nodes_profit.resize(total_nodes+1,0);		
	
	results_file<<"Total Nodes are: "<<tot_nodes<<endl;
	//intializing space for all nodes.
	//And initializing parents.
	int counter=1;
	for(int i=1;i<tot_levels;i++)
	{
		int nodes=pow(n_ary,i);
		for(int j=0;j<nodes;j++)
		{
			nodes_space[counter]=space[i];
			int temp=counter%n_ary;
			int x= counter/n_ary;
			if(temp==0)	x--;
			cout<<"Counter: "<<counter<<" parent: "<<x<<"\n";
			parent[counter]=x;
			counter++;
		}
	}

	//Printing nodes space for all nodes;
	for(int i=0;i<nodes_space.size();i++)
	{
		cout<<"Node: "<<i<<" space: "<<nodes_space[i]<<" parent: "<<parent[i]<<"\n";
	}
	//Now initializing requests.
	//Location should be from leaf nodes only.
	//Need to take this from file.
	fstream data_file;
	data_file.open("Data/data_file_4_4_10000_rd.txt");
	if(!data_file.is_open())
	{
		cout<<"File Can't be opened\n";
		exit(0);
	}

	data_file>>tot_requests;
	int tot_prf=0;
	for(int i=0;i<tot_requests;i++)
	{
		int ci,li,di,pi;
		data_file>>ci>>li>>di>>pi;
		vector<int> r;
		r.push_back(ci),r.push_back(li),r.push_back(di),r.push_back(pi);
		req.push_back(r);
		tot_prf+=pi;
	}
	// for(int i=0;i<tot_requests;i++)
	// {
	// 	cout<<req[i][0]<<req[i][1]<<req[i][2]<<req[i][3]<<"\n";
	// }
	data_file.close();
	results_file<<"Total possible profit: "<<tot_prf<<"\n";
}

//From leaf node we can make an path from leaf to cloud using it's parent property.

//For each request this function makes its path to cloud and returns the path.
vector<int> make_path(vector<int> &single_req)
{
	int curr_node=single_req[1];
	int dead_i=single_req[2];
	int curr_level=tot_levels-1;
	vector<int> path;
	//Untill we reach cloud or deadline has came.
	while(dead_i>=delay[curr_level] && curr_node!=0)
	{
		path.push_back(curr_node);
		curr_node=parent[curr_node];
		curr_level--;
	}
	if(dead_i>=delay[0])	path.push_back(0);
	return path;
}

//For each content filter all the requests and sumup total profit from it.
//So each content will be having collection of paths and total sum of profit.
//mapping would be content total profit sum and requests in it.
//for each requests we will be having mapping of its path.

//This function has mapping of each requests with its path.
unordered_map<int,vector<int>> req_path;
unordered_map<int,vector<int>> content_req;
//profit-content relation  
vector<pair<int,int>> pr_cont;

void mapping_req_path()
{
	//cout<<"Developing Path for each requests\n";
	for(int i=0;i<tot_requests;i++)
	{
		req_path[i]=make_path(req[i]);			//Gives me path for corresponding request.
		//cout<<"Request "<<i<<" Path size "<<req_path[i].size()<<"\n";
		content_req[req[i][0]].push_back(i);	//Gives me requests for corresponding content.
	}
	for(auto m:content_req)						// For each content we here find its total profit.
	{
		vector<int> temp=m.second;
		int sum=0;
		for(auto v:temp)
		{
			sum+=req[v][3];
		}
		pr_cont.push_back({sum,m.first});
	}
	sort(pr_cont.rbegin(),pr_cont.rend());	//Sort based on total profit in decreasing fashion.
	// for(int i=0;i<pr_cont.size();i++)
	// {
	// 	cout<<pr_cont[i].first<<" "<<pr_cont[i].second<<"\n";
	// }
}

//for a content consider all requests for it.
//Now start with first node of all requests.
//If deadline of any content recieved place it over there and decrease space of that node.
//Add profit to that particular nodes list.
// If no space release the lowest profit giving content and add current to it.
//After release find all request related to it and for each traverse in its path for any space if possible.
void lca_placement(int con_id,int profit)
{
	//Find all requests for this particular contet;
	vector<int> requests_for_content=content_req[con_id];
	//cout<<"No of requests for content: "<<con_id<<" "<<requests_for_content.size()<<"\n";
	//Finding paths for each requests;
	vector<vector<int>> paths;
	for(auto m:requests_for_content)
	{
		//cout<<"request: "<<m<<" has leaf "<<req[m][1]<<" and has path size: "<<req_path[m].size()<<"\n";
		paths.push_back(req_path[m]);
	}
	//Now traversing each paths until we reach cloud or lca.
	bool lca_found=false;						//Currently LCA is not found.
	int curr_level=tot_levels;					//current level is leafs level so total level our cloud is at level 1.
	vector<bool> req_satisfied(paths.size(),false);
	int earned_profit=0;
	// //If path size is equal to cloud length we can directly place it on cloud.
	// for(int i=0;i<paths.size();i++)
	// {
	// 	if(paths[i].size()==tot_levels)
	// 	{
	// 		earned_profit+=req[requests_for_content[i]][3];
	// 		req_satisfied[i]=true;
	// 	}
	// }
	while(!lca_found && curr_level!=1)
	{
		//node requests map gives knowledge of how many requests are there at each node for this particular content.
		//Useful to get LCA easily if mp size ==1 means all requests on one node.
		unordered_map<int,vector<int>> mp;
		//set of requests which need to be placed at current level.
		unordered_map<int,vector<int>> node_req;
		for(int i=0;i<paths.size();i++)
		{
			if(!req_satisfied[i] && paths[i].size()-1==tot_levels-curr_level)
			{
				//Need to place in this node.
				//req_curr_level.push_back(i);
				// int x=req[requests_for_content[i]][3];
				// profit-=x;
				// req_satisfied[i]=true;
				// int curr_node=paths[i][tot_levels-curr_level];
				// if(nodes_content[curr_node].count(con_id)!=0)
				// {
				// 	int prf=nodes_content[curr_node][con_id];
					
				// }
				// nodes_profit[curr_node][x].push_back(requests_for_content[i]);
				// nodes_space[paths[i][tot_levels-curr_level]]--;
				node_req[paths[i][tot_levels-curr_level]].push_back(i);
			}
			if(!req_satisfied[i] && paths[i].size()>tot_levels-curr_level)
			{
				//Allowed for next level.
				//node_req[paths[i][tot_levels-curr_level]].push_back(i);
				mp[paths[i][tot_levels-curr_level]].push_back(i);
			}
		}
		//cout<<"Size of mp "<<mp.size()<<" Node req "<<node_req.size()<<"\n";
		if(mp.size()==1){
			lca_found=true;
			auto first_item=mp.begin();
			int lca_node = first_item->first;
			nodes_space[lca_node]--;

			//Also all the request for this content should be entered.
			vector<int> requests_node=first_item->second;
			int prf=0;
			//Summed all request at that node and add each request to that node.
			for(auto r:requests_node)
			{
				prf+=req[requests_for_content[r]][3];
				nodes_content_req[lca_node][con_id].push_back(requests_for_content[r]);
				req_satisfied[r]=true;
			}
			//cout<<"Node it is stored: "<<lca_node<<" profit it gave: "<<prf<<"\n";
			nodes_profit_content[lca_node].insert({prf,con_id});
			if(nodes_space[lca_node]<0)
			{

				//need to remove content with lowest profit.
				//From nodes_profit_content remove the lowest.
				//We will get lowest ones content
				//From nodes_content_req we will get all the requests for that content.
				//Now for each requests we will just traverse in top down fashion and
				//Add them if there is space.
					auto it=nodes_profit_content[lca_node].begin();
					int con_remove=it->second;
					nodes_profit_content[lca_node].erase(it);
					nodes_space[lca_node]++;
					nodes_content_req[lca_node].erase(con_remove);
				//cout<<"Content removed: "<<con_remove<<" node size "<<nodes_profit_content[lca_node].size()<<"\n";
			}
			//LCA found so we can break
			return;
		}
		else if(node_req.size()!=0)
		{
			//Traversing each node in the current level which has a path completed.
			for(auto v:node_req)
			{
				//first we got the node and then corresponding requests which had path limited till there.
				int nd=v.first;

				std::vector<int> requests_node=v.second;
				int prf=0;
				//cout<<"Node "<<nd<<" "<<requests_node.size()<<"\n";
				for(auto r:requests_node)
				{
					prf+=req[requests_for_content[r]][3];
					//cout<<"Reached"<<"\n";
					nodes_content_req[nd][con_id].push_back(requests_for_content[r]);
					req_satisfied[r]=true;
				}
				//cout<<"Reached"<<"\n";
				nodes_space[nd]--;
				//We need to decrease space of node.
				//Also that node got this much profit from this content that should be stored.
				//Also we need to store which requests of that content are stored in that node.
				nodes_profit_content[nd].insert({prf,con_id});

				if(nodes_space[nd]<0)
				{
					//need to remove content with lowest profit.
					auto it=nodes_profit_content[nd].begin();
					int con_remove=it->second;
					nodes_profit_content[nd].erase(it);
					nodes_space[nd]++;
					nodes_content_req[nd].erase(con_remove);
				}
			}
		}
		curr_level--;
	}
	//cout<<"requests which req_satisfied by cloud: ";
	int prf=0;
	for(int i=0;i<req_satisfied.size();i++)
	{
				
		if(!req_satisfied[i] && paths[i].size()==tot_levels)
		{
			//nodes_content_req[con_id].push_back(requests_for_content[i]);
			prf+=req[requests_for_content[i]][3];
			//cout<<requests_for_content[i]<<" ";
		}
		//cout<<"\n";
		
	}
	if(prf>0)	nodes_profit_content[0].insert({prf,con_id});
	return;
}

int main()
{
	intialize_architecture();
	mapping_req_path();
	for(int i=0;i<pr_cont.size();i++)
	{
		lca_placement(pr_cont[i].second,pr_cont[i].first);	
	}
	//Now for each nodes we have their profit we will sum them up and get the total.
	int net_profit=0;
	for(int nd=0;nd<tot_nodes;nd++)
	{
		multimap<int,int> mp=nodes_profit_content[nd];

		if(mp.size()>0)
		{
			int prf_node=0;
			results_file<<"Node "<<nd<<" content stored: ";
			for(auto m:mp)
			{
				prf_node+=m.first;
				results_file<<m.second<<" ";
			}
			net_profit+=prf_node;
			results_file<<" gives profit: "<<prf_node<<"\n";
		}
	}
	results_file<<"Total Net profit we earned: "<<net_profit<<"\n";
	return 1;
}
